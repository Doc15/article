create database blog;
use blog;


create table article(id_item int auto_increment primary key,
  name_article varchar(200),
  id_category int,
  id_user int, date date);

create table users(id_us int auto_increment primary key,
  login varchar(50),
  password varchar(50),
  email varchar(50),
  id_role int);
  
create table  category(id_cat int auto_increment primary key,
  title varchar(50));
  
create table role(id_r int auto_increment primary key,
  title_role varchar(45));
  
  create table  tags(id_cat int auto_increment primary key,
  title varchar(20));
ALTER TABLE article ADD FOREIGN KEY (id_category) REFERENCES  category(id_cat);
ALTER TABLE article ADD FOREIGN KEY (id_user) REFERENCES users(id_us);
ALTER TABLE users ADD FOREIGN KEY (id_role) REFERENCES role(id_r);


insert into article(name_article, id_category, id_user, date, id_tag, description) values ('СКАЗОЧНЫЙ ГОСУДАРСТВЕННЫЙ ПАРК PALOUSE FALLS', 1, 3, '2021-02-15'), 
('КАК ОРГАНИЗОВАТЬ СЕБЯ? 10 ПРИВЫЧЕК, КАК ИСПОЛЬЗОВАТЬ СВОЕ ВРЕМЯ ЭФФЕКТИВНО', 2, 2, '2021-03-18'), 
( 'КАК ПОВЫСИТЬ РАБОТОСПОСОБНОСТЬ?', 3, 4, '2021-03-23'), 
('ПРЕКРАСНЫЕ ШЕДЕВРЫ КЛАССИЧЕСКОЙ МУЗЫКИ', 4, 5, '2021-04-30');
insert into category(title) values ('КРАСИВЫЕ МЕСТА АМЕРИКИ'), ('СОВЕТЫ ДНЯ'), ('ПСИХОЛОГИЯ'), ('ИСКУССТВО И ИСТОРИЯ');
insert into role(title_role) values ('admin'), ('bloger'), ('editor');
insert into users(login, password, email, id_role) values ('admin', 'admin', 'admin@gmail.com', 1) ('Geqo', 'gika', 'Geqo@gmail.com', 2), ('Bafovelis', 'bafo', 'Bafovelis@gmail.com', 2), ('Hexa', 'pass', 'Неха@gmail.com', 2), ('Zora', 'rouse', 'zora@gmail.com', 3);
  

INSERT INTO `article`(name_article, id_category, id_user, date, id_tag, description) VALUES 
('КАК ОРГАНИЗОВАТЬ СЕБЯ? 10 ПРИВЫЧЕК, КАК ИСПОЛЬЗОВАТЬ СВОЕ ВРЕМЯ ЭФФЕКТИВНО',2,2,'2021-03-18',2, '1. Планируйте свой день заблаговременно. 2. Определите цели. 3. Главные приоритеты. 4. Делегируйте. 5. Записывайте вещи, которые вы должны сделать.'),
('КАК ПОВЫСИТЬ РАБОТОСПОСОБНОСТЬ?',3,4,'2021-03-23',3, 'Для улучшения работоспособности в рацион следует добавить больше простых и сложных углеводов и дополнить их белками и минералами.'),
('ПРЕКРАСНЫЕ ШЕДЕВРЫ КЛАССИЧЕСКОЙ МУЗЫКИ',4,5,'2021-04-30',4, 'Шопен, Моцарт, Шуберт, Мусоргский, Бах, Чайковский, Вивальди, Бетховен, Дебюсси'),
('топ 5 лучших книг 20 века', 4, 2,'2021-03-17', 4, '1. Убить пересмешника Автор книги: Харпер Ли. 2. 1984 Автор книги: Джордж Оруэлл 3. Властелин Колец Автор книги: Джон Рональд Руэл Толкин 4. Над пропастью во ржи Автор книги: Джером Дэвид Сэлинджер 5. Великий Гэтсби Автор книги: Фрэнсис Скотт Фицджеральд');



"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysqlump.exe" -uroot -p blog > C:\Users\user\Desktop\шарага\blog.sql



 ALTER TABLE article CHANGE  name_article name_article varchar(200);
  ALTER TABLE article ADD COLUMN  description text;
  ALTER TABLE tags CHANGE id_t id_t int;

ALTER TABLE tags CHANGE title id_t varchar(20);

  insert into article 


  	insert into tags(title) values ('Природа'), ('Советы'), ('Психолоия'), ('Искусство');



  		update article set id_tag=2 where id_item = 6;
update article set id_tag=3 where id_item = 7;
	update article set id_tag=4 where id_item = 8;
		update article set id_tag=4 where id_item = 12;




  		insert into article(id_tag) values (3) where id_item = 7;
  	    insert into article(id_tag) values (4) where id_item = 8;
  		insert into article(id_tag) values (4) where id_item = 12;

  UPDATE `news`
SET `text` = 'The very first news'
WHERE `id` = 1;

  ALTER TABLE article
ALTER COLUMN id_tag SET 6;
ALTER TABLE article
ALTER COLUMN id_tag SET DEFAULT 7;
ALTER TABLE article
ALTER COLUMN id_tag SET DEFAULT 8;
ALTER TABLE article
ALTER COLUMN id_tag SET DEFAULT 12;



UPDATE article
SET  description = '1. Планируйте свой день заблаговременно.
2. Определите цели.
3. Главные приоритеты.
4. Делегируйте.
5. Записывайте вещи, которые вы должны сделать.
6. Меньше отвлекайтесь!
7. Перерывы.
8. Скажите: «Нет».
9. Сроки.
10. Перепроверка.'
WHERE id_item = 6;
  
UPDATE article
SET  description = 'Повысить работоспособность помогут дыхательные техники, адаптогенные травы, массаж, правильный сон и другие советы от Лайфхакера.'
WHERE id_item = 7;
 
UPDATE article
SET  description = 'танец с саблями.
Утро и "в пещере горного короля".  "щелкунчик" или "вальс цветов".'
WHERE id_item = 8;

UPDATE article
SET  description = '1. Приключения Шерлока Холмса  Артур Конан Дойль.
2. Игра Эндера Эрнест Хемингуэй.
3. Заводной апельсин Энтони Берджесс.
4. Мастер и Маргарита Михаил Булгаков.
5. Цветы для Элджернона Дэниэл Киз.
6. Великий Гэтсби Фрэнсис Скотт Фицджеральд
7. Гарри Поттер и философский камень Джоан Роулинг
8. Автостопом по галактике Дуглас Адамс
9. Рассказ Служанки Маргарет Этвуд
10. Хроники Нарнии Клайв Стэйплз Льюис'
WHERE id_item = 12;


